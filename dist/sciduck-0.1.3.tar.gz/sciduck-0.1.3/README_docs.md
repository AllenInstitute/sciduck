sphinx-quickstart ## in docs
sphinx-apidoc -o docs/source src/sciduck/