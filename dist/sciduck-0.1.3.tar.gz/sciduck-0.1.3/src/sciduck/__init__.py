"""
sciduck

single cell data analyis unification and communication toolkit
"""

__version__ = "0.1.2"
__author__ = 'Nelson Johansen'
__credits__ = 'Allen Institute for Brain Science'
