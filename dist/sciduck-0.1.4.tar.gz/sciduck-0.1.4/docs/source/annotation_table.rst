sciduck.annotation\_table module
--------------------------------

.. automodule:: sciduck.annotation_table
   :members:
   :undoc-members:
   :show-inheritance:
