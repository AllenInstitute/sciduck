sciduck.basic\_qc module
------------------------

.. automodule:: sciduck.basic_qc
   :members:
   :undoc-members:
   :show-inheritance:
