sciduck.entropy\_qc module
--------------------------

.. automodule:: sciduck.entropy_qc
   :members:
   :undoc-members:
   :show-inheritance:
